# Purlin Production ML Project

Machine-learning analysis of purlin manufacturing logs (April-June 2026).

**Task 1 - Machine classification:** predict which machine (New Machine, No.1, No.2) ran a job
from its specification (thickness, width, GSM, length, purlin count, unit weight, customer group).

## Project structure
```
data/processed/purlin_clean.csv   cleaned, model-ready data (2,953 rows)
src/prepare_data.py               raw logs -> purlin_clean.csv
src/train_machine.py              trains 5 models, 2 split strategies, writes figures + model
app/streamlit_app.py              interactive predictor
models/machine_pipeline.joblib    saved best pipeline (created by training)
figures/                          comparison chart, confusion matrix, feature importance
results_machine.csv               full results table (20 runs)
report/                           final project report
```

## Setup
```bash
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## Run
```bash
python src/prepare_data.py          # only if starting from raw logs
python src/train_machine.py         # trains, evaluates, saves model + figures
streamlit run app/streamlit_app.py  # opens the predictor in your browser
```
Run all commands from the project root. The app works on phones too: open the "Network URL"
Streamlit prints while on the same Wi-Fi.

## Method summary
- **Features:** 6 numeric (standardised) + customer group (one-hot).
- **Models:** Logistic Regression, KNN, SVM (RBF), Random Forest, Gradient Boosting; each tuned with
  5-fold stratified `GridSearchCV` on macro-F1.
- **Splits:** random stratified 80/20, and time-based (train Apr-May, test Jun).
- **Baseline:** majority class (always "New Machine").

## Key results (macro-F1 on test set, with customer group)
| Model | Random split | Time split |
|---|---|---|
| Gradient Boosting | **0.964** | 0.706 |
| Random Forest | 0.957 | 0.728 |
| KNN | 0.915 | 0.759 |
| SVM (RBF) | 0.889 | **0.861** |
| Logistic Regression | 0.824 | 0.617 |
| Majority baseline | 0.278 | 0.306 |

**Read the time-split column.** 43.8% of random-split test rows have an identical feature vector in
the training set (0.2% for the time split), because the same job repeats across many coils. The
random split therefore rewards memorisation; the time split reflects deployment.

## Notes / limitations
- Dropping customer group cuts random-split macro-F1 from 0.96 to 0.88 (GB) - customers are
  routed to particular machines.
- `UNIT_WEIGHT_KG` is exactly thickness x width x length x 7850 / 1e9, so it adds no information
  beyond the dimensions.
- Only 3 months of data; the June test set has 1,169 rows and a shifted class mix.
- Results can differ slightly between scikit-learn versions.
