const fs=require('fs');
const {Document,Packer,Paragraph,TextRun,Table,TableRow,TableCell,ImageRun,HeadingLevel,AlignmentType,WidthType,ShadingType,BorderStyle,LevelFormat,Footer,PageNumber}=require('docx');
const F='../figures/';
const P=(t,o={})=>new Paragraph({spacing:{after:120,line:300},...o,children:Array.isArray(t)?t:[new TextRun(t)]});
const B=(t)=>new TextRun({text:t,bold:true});
const H1=t=>new Paragraph({heading:HeadingLevel.HEADING_1,children:[new TextRun(t)]});
const H2=t=>new Paragraph({heading:HeadingLevel.HEADING_2,children:[new TextRun(t)]});
const bullet=(t)=>new Paragraph({numbering:{reference:'b',level:0},spacing:{after:60},children:Array.isArray(t)?t:[new TextRun(t)]});
const img=(f,w,h)=>new Paragraph({alignment:AlignmentType.CENTER,spacing:{before:120,after:60},children:[new ImageRun({type:'png',data:fs.readFileSync(F+f),transformation:{width:w,height:h},altText:{title:f,description:f,name:f}})]});
const cap=t=>new Paragraph({alignment:AlignmentType.CENTER,spacing:{after:200},children:[new TextRun({text:t,italics:true,size:19,color:'555555'})]});
const bd={style:BorderStyle.SINGLE,size:4,color:'BBBBBB'};const borders={top:bd,bottom:bd,left:bd,right:bd};
function table(widths,rows){
  const total=widths.reduce((a,b)=>a+b,0);
  return new Table({width:{size:total,type:WidthType.DXA},columnWidths:widths,rows:rows.map((r,i)=>new TableRow({tableHeader:i===0,children:r.map((c,j)=>new TableCell({borders,width:{size:widths[j],type:WidthType.DXA},margins:{top:60,bottom:60,left:100,right:100},
    shading:i===0?{type:ShadingType.CLEAR,fill:'DCE6F5',color:'auto'}:undefined,
    children:[new Paragraph({alignment:j===0?AlignmentType.LEFT:AlignmentType.CENTER,children:[new TextRun({text:String(c),bold:i===0,size:20})]})]}))}))});
}
const doc=new Document({
  styles:{default:{document:{run:{font:'Arial',size:22}}},paragraphStyles:[
   {id:'Heading1',name:'Heading 1',basedOn:'Normal',next:'Normal',quickFormat:true,run:{size:30,bold:true,font:'Arial',color:'1F3864'},paragraph:{spacing:{before:300,after:140},outlineLevel:0}},
   {id:'Heading2',name:'Heading 2',basedOn:'Normal',next:'Normal',quickFormat:true,run:{size:25,bold:true,font:'Arial',color:'2E5597'},paragraph:{spacing:{before:200,after:100},outlineLevel:1}}]},
  numbering:{config:[{reference:'b',levels:[{level:0,format:LevelFormat.BULLET,text:'•',alignment:AlignmentType.LEFT,style:{paragraph:{indent:{left:720,hanging:360}}}}]}]},
  sections:[{properties:{page:{size:{width:11906,height:16838},margin:{top:1440,right:1440,bottom:1440,left:1440}}},
   footers:{default:new Footer({children:[new Paragraph({alignment:AlignmentType.CENTER,children:[new TextRun({children:['Page ',PageNumber.CURRENT],size:18,color:'777777'})]})]})},
   children:[
    new Paragraph({alignment:AlignmentType.CENTER,spacing:{before:1800,after:200},children:[new TextRun({text:'Machine Classification and Yield Analysis for Purlin Manufacturing',bold:true,size:44,color:'1F3864'})]}),
    new Paragraph({alignment:AlignmentType.CENTER,spacing:{after:200},children:[new TextRun({text:'A Machine Learning Lab Project Report',size:28,color:'555555'})]}),
    new Paragraph({alignment:AlignmentType.CENTER,spacing:{after:80},children:[new TextRun({text:'Production logs: April – June 2026',size:24})]}),
    new Paragraph({alignment:AlignmentType.CENTER,spacing:{after:80},children:[new TextRun({text:'[Your name]  |  [Roll no.]  |  [Course / Institution]',size:24,color:'888888'})]}),
    new Paragraph({children:[new TextRun({text:'',break:1})],pageBreakBefore:true}),

    H1('1. Introduction'),
    P('Purlin production runs on three machines (New Machine, Machine No.1 and Machine No.2). Each job is logged with its steel coil, customer, dimensions, coating weight and number of purlins produced. This project builds an end-to-end machine-learning pipeline on those logs: automated data cleaning, model training and evaluation, and an interactive application for inference.'),
    P('Two tasks were defined. Task 1 predicts which machine ran a job from its specification. Task 2 explores regression of production yield. Task 1 is the main contribution and is evaluated carefully; Task 2 is reported with caveats (Section 6).'),

    H1('2. Data and Preparation'),
    P('The raw logs were converted to a clean dataset (purlin_clean.csv, 2,953 rows, 78 production days from 2 April to 28 June 2026) by prepare_data.py. Numeric columns were coerced with errors set to NaN, dates parsed, and text fields stripped and upper-cased. Cleaning then proceeded in four steps:'),
    bullet('Remove downtime rows (party name contains “OFF”) and rows where every specification field is blank.'),
    bullet('Drop rows missing any essential dimension: thickness, width, length or purlin count.'),
    bullet('Remove exact duplicate rows across all columns.'),
    bullet('Remove values outside physical plausibility limits (sensor or entry errors).'),
    P('Customers were consolidated into 18 groups (PARTY_GROUP), including a catch-all “OTHER” group. A flag marks rows where GSM was imputed (about 10% of rows).'),
    H2('2.1 Target distribution'),
    P('The classes are imbalanced: New Machine 2,119 jobs (71.8%), Machine No.1 509 (17.2%), Machine No.2 325 (11.0%). The class mix also drifts over time: Machine No.1 ran 250 jobs in April but 109 in June, while New Machine rose from 619 to 991. Because of this imbalance, accuracy alone is misleading and macro-F1 is the primary metric.'),
    H2('2.2 Derived quantity'),
    P([new TextRun('Unit weight is an exact function of the dimensions in this data: '),B('UNIT_WEIGHT_KG = thickness × width × length × 7850 / 10⁹'),new TextRun(' (steel density 7,850 kg/m³; ratio of 1.000 on every row). It therefore adds no independent information, although it is retained as a convenient scaled feature.')]),

    H1('3. Methodology (Task 1)'),
    H2('3.1 Features'),
    P('Six numeric features (thickness, width, GSM, length, purlin count, unit weight) were standardised; customer group was one-hot encoded with unknown categories ignored. All preprocessing lives inside a scikit-learn Pipeline so that scaling is fitted only on training folds.'),
    H2('3.2 Models and tuning'),
    P('Five classifiers were trained: Logistic Regression, K-Nearest Neighbours, SVM with RBF kernel, Random Forest and Gradient Boosting. Each was tuned with five-fold stratified GridSearchCV optimising macro-F1 (class weighting “balanced” where supported). Every model was run with and without the customer feature to measure its contribution.'),
    H2('3.3 Two evaluation splits'),
    bullet([B('Random split: '),new TextRun('stratified 80/20 (2,362 train / 591 test).')]),
    bullet([B('Time split: '),new TextRun('train on April–May (1,784 rows), test on June (1,169 rows). This mimics deployment, where the model predicts future jobs.')]),
    P('A majority-class predictor (always “New Machine”) is the baseline: macro-F1 0.278 on the random test set and 0.306 on the time-split test set; accuracy 0.717 and 0.848 respectively.'),

    H1('4. Results'),
    H2('4.1 Model comparison'),
    table([2600,1500,1500,1700,1700],[
      ['Model (with customer)','Random acc.','Random F1','Time acc.','Time F1'],
      ['Gradient Boosting','0.978','0.964','0.869','0.706'],
      ['Random Forest','0.975','0.957','0.846','0.728'],
      ['KNN','0.946','0.915','0.923','0.759'],
      ['SVM (RBF)','0.931','0.889','0.958','0.861'],
      ['Logistic Regression','0.880','0.824','0.749','0.617'],
      ['Majority baseline','0.717','0.278','0.848','0.306']]),
    cap('Table 1. Test-set accuracy and macro-F1 for each model and split.'),
    img('model_comparison.png',600,231),
    cap('Figure 1. Macro-F1 on the test set; the best model in each split is highlighted.'),
    P('On the random split the tree ensembles dominate (Gradient Boosting 0.964, Random Forest 0.957). On the time split the ranking changes completely: SVM leads at 0.861 and both tree ensembles drop to roughly 0.71–0.73. Cross-validation scores (0.95 for the ensembles) were far above the time-split test scores, a further sign of distribution shift.'),
    H2('4.2 Error analysis'),
    img('confusion_matrix.png',340,295),
    cap('Figure 2. Gradient Boosting confusion matrix on the random-split test set.'),
    P('Of 591 test jobs, 578 were classified correctly (97.8%). There were 13 errors in total; Machine No.1 had the most misses (7 of 102), mostly predicted as New Machine. No class was systematically ignored, which the balanced class weights help to ensure.'),
    H2('4.3 Feature importance and the customer feature'),
    img('feature_importance.png',420,270),
    cap('Figure 3. Top ten Random Forest feature importances (random split).'),
    P('Coating weight (GSM) and the geometry features carry most of the signal, followed by several customer groups (PEB, SISCOL, MECHA STEEL). Removing the customer feature confirms its importance:'),
    table([2600,1500,1500,1700,1700],[
      ['Model','Random F1 with','Random F1 without','Time F1 with','Time F1 without'],
      ['Gradient Boosting','0.964','0.880','0.706','0.542'],
      ['Random Forest','0.957','0.851','0.728','0.634'],
      ['SVM (RBF)','0.889','0.715','0.861','0.537'],
      ['KNN','0.915','0.806','0.759','0.578'],
      ['Logistic Regression','0.824','0.630','0.617','0.587']]),
    cap('Table 2. Effect of removing the customer-group feature (macro-F1).'),
    P('Specifications alone are therefore not enough to separate the machines; customers are routed to particular machines, and that routing is what the models exploit.'),

    H1('5. Discussion'),
    H2('5.1 The random split overstates performance'),
    P('The same job (same customer and dimensions) is typically produced from several coils, so near-identical rows appear many times. In this dataset 43.8% of the random-split test rows have an exact feature match in the training set, against 0.2% for the time split. A random split therefore partly tests memorisation. The time split is the more honest estimate of how the model will behave on new jobs, and the report’s headline conclusions are based on it.'),
    H2('5.2 Model choice'),
    P('The 0.964 vs 0.861 gap is large enough to change the recommendation. Gradient Boosting wins on the random split but is not the best choice for deployment; SVM is the most robust under temporal shift (accuracy 0.958, macro-F1 0.861). Only SVM clearly beats the 0.848 majority-class accuracy on the time split; the tree ensembles reach 0.846–0.869, which is barely above guessing “New Machine” when judged by accuracy alone, although their macro-F1 is much higher than the baseline’s 0.306 because they do recognise the minority machines. It is recommended to retrain periodically on recent data and to use a time-based split for model selection.'),
    H2('5.3 Limitations'),
    bullet('Only three months of data; the June test set has a different class mix from the training months.'),
    bullet('Machine assignment may depend on factors not recorded (operator decisions, machine availability, scheduling).'),
    bullet('Best-model selection and exact scores can vary slightly between scikit-learn versions and seeds.'),

    H1('6. Task 2: Yield Regression'),
    P('Yield is recorded as a percentage of coil weight converted to product and is available for only 534 of the 2,953 rows (those with a recorded coil quantity). Regression from job specifications alone reached R² ≈ 0.36. Adding the purlin count raised R² to about 0.93.'),
    P('This jump should be interpreted cautiously. In the data, production weight equals unit weight multiplied by the purlin count (checked on the first rows: 31.56 kg × 53 = 1,672.7 kg). Yield is production relative to coil weight, so once the purlin count is known, most of the numerator is determined by a formula rather than learned. The high R² reflects an arithmetic dependency and not predictive power available before production. A fair forecasting model should exclude features that are only known after the job completes. These figures come from the earlier regression script (train_yield.py) and were not re-run for this report.'),

    H1('7. Deployment: Streamlit Application'),
    P('A Streamlit app (app/streamlit_app.py) loads the saved pipeline and lets a user enter thickness, width, length, GSM, purlin count and customer group. Unit weight is computed automatically from the dimensions, with an optional manual override. The app displays the predicted machine with class probabilities, warns when inputs fall outside the training range or the customer is unknown, and uses a responsive single-column layout that works on mobile browsers.'),

    H1('8. Conclusions'),
    bullet('Machine type can be predicted well from job specification plus customer group: macro-F1 up to 0.96 on a random split and 0.86 on a future-month test, versus baselines of 0.28–0.31.'),
    bullet('Customer group is the key signal; without it macro-F1 falls by 0.03–0.32 depending on model and split.'),
    bullet('Random-split results are inflated by repeated jobs; time-based validation should be used, under which SVM is the most robust model.'),
    bullet('The high yield R² is driven by a formula dependency and should not be presented as forecasting skill.'),
    P('Future work: collect more months of data, test group-aware cross-validation (grouping by job), add scheduling features, and rebuild the yield model using only pre-production information.'),

    H1('Appendix: Repository'),
    P('Code, data, figures and the app are organised as described in README.md: src/ (prepare_data.py, train_machine.py), app/streamlit_app.py, models/, figures/, data/processed/purlin_clean.csv, results_machine.csv.')
  ]}]});
Packer.toBuffer(doc).then(b=>{fs.writeFileSync('/home/claude/purlin-ml/report/Purlin_ML_Project_Report.docx',b);console.log('ok')});
